﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Guia4_Progra_Otravez
{
    public partial class Form1 : Form
    {

        bool prendido = false;
        double vol = 1, can = 1;

        public Form1()
        {
            InitializeComponent();
          
        }



        private void button1_Click(object sender, EventArgs e)
        {
            prendido = !prendido;
            if (prendido == false) { button1.BackColor = Color.Red;
                label4.Text = "Apagado";
            }
            else if (prendido == true) { button1.BackColor = Color.Green;
                label4.Text = "Encendido";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (prendido == true)
            {
                if (vol <= 30 && vol >= 1)
                {
                    vol = vol - 1;

                    textBox1.Text = "Volumen " + vol;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (prendido == true)
            {
                if (can <= 75 && can >= 1)
                {
                    can++;

                    textBox2.Text = "Canal " + can;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (prendido == true)
            {
                if (can <= 75 && can >= 2)
                {
                    can = can - 1;

                    textBox2.Text = "Canal " + can;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (prendido == true)
            {
                if (vol <= 30 && vol >= 0)
                {
                    vol++;

                    textBox1.Text = "Volumen " + vol;
                }
            }
        }
    }
}
