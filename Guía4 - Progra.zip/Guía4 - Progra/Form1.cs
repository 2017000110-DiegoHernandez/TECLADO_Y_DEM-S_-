﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Guía4___Progra
{
    public partial class Form1 : Form
    {
        bool esMayuscula = true;
       
        public Form1()
        {
            InitializeComponent();
        }
        private void Tecla(object sender, EventArgs e) 
        {
            if (sender is Button boton) 
            {
                string txt = boton.Text;
                textBox1.Text += txt;
            }
        }

        private void ActualizarTextoBotones(Control parent)
        {
            foreach (Control control in parent.Controls)
            {
                if (control is Button btn)
                {
                    // Solo cambiamos los botones que tienen 1 sola letra (A-Z, Ñ)
                    if (btn.Text.Length == 1 && char.IsLetter(btn.Text[0]))
                    {
                        btn.Text = esMayuscula ? btn.Text.ToUpper() : btn.Text.ToLower();
                    }
                }

                if (control.HasChildren)
                {
                    ActualizarTextoBotones(control);
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Tecla(sender, e);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button29_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            esMayuscula = !esMayuscula;

            ActualizarTextoBotones(this);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0)
            {
                // Eliminamos el último carácter reduciendo la longitud en 1
                textBox1.Text = textBox1.Text.Substring(0, textBox1.Text.Length - 1);
            }
        }
    }
}
