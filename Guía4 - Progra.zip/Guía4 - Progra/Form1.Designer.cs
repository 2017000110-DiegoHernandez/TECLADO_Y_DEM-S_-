﻿namespace Guía4___Progra
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.label5 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(66, 106);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(31, 30);
            this.button1.TabIndex = 1;
            this.button1.Text = "W";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Tecla);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(30, 106);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(30, 29);
            this.button2.TabIndex = 1;
            this.button2.Text = "Q";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Tecla);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(400, 106);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(56, 31);
            this.button3.TabIndex = 1;
            this.button3.Text = "Salir";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(30, 44);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(508, 26);
            this.textBox1.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(171, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Diego Hernández 17";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(138, 105);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(31, 30);
            this.button4.TabIndex = 1;
            this.button4.Text = "R";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Tecla);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(102, 105);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(30, 29);
            this.button5.TabIndex = 1;
            this.button5.Text = "E";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.Tecla);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(211, 107);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(31, 30);
            this.button6.TabIndex = 1;
            this.button6.Text = "Y";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.Tecla);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(283, 106);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(31, 30);
            this.button7.TabIndex = 1;
            this.button7.Text = "I";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.Tecla);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(175, 107);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(30, 29);
            this.button8.TabIndex = 1;
            this.button8.Text = "T";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.Tecla);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(247, 106);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(30, 29);
            this.button9.TabIndex = 1;
            this.button9.Text = "U";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.Tecla);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(327, 108);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(31, 30);
            this.button10.TabIndex = 1;
            this.button10.Text = "O";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.Tecla);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(363, 107);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(30, 29);
            this.button12.TabIndex = 1;
            this.button12.Text = "P";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.Tecla);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(66, 142);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(31, 30);
            this.button13.TabIndex = 1;
            this.button13.Text = "S";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.Tecla);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(138, 141);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(31, 30);
            this.button14.TabIndex = 1;
            this.button14.Text = "F";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.Tecla);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(211, 143);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(31, 30);
            this.button15.TabIndex = 1;
            this.button15.Text = "H";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.Tecla);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(283, 142);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(31, 30);
            this.button16.TabIndex = 1;
            this.button16.Text = "K";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.Tecla);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(327, 144);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(31, 30);
            this.button17.TabIndex = 1;
            this.button17.Text = "L";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.Tecla);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(399, 143);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(57, 30);
            this.button18.TabIndex = 1;
            this.button18.Text = "C";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(30, 142);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(30, 29);
            this.button19.TabIndex = 1;
            this.button19.Text = "A";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.Tecla);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(175, 143);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(30, 29);
            this.button20.TabIndex = 1;
            this.button20.Text = "G";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.Tecla);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(102, 141);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(30, 29);
            this.button21.TabIndex = 1;
            this.button21.Text = "D";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.Tecla);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(247, 142);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(30, 29);
            this.button22.TabIndex = 1;
            this.button22.Text = "J";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.Tecla);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(363, 143);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(30, 29);
            this.button23.TabIndex = 1;
            this.button23.Text = "Ñ";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.Tecla);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(66, 178);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(31, 30);
            this.button24.TabIndex = 1;
            this.button24.Text = "X";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.Tecla);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(138, 177);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(31, 30);
            this.button25.TabIndex = 1;
            this.button25.Text = "V";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.Tecla);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(211, 179);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(31, 30);
            this.button26.TabIndex = 1;
            this.button26.Text = "N";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.Tecla);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(283, 178);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(31, 30);
            this.button27.TabIndex = 1;
            this.button27.Text = ",";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.Tecla);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(327, 180);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(31, 30);
            this.button28.TabIndex = 1;
            this.button28.Text = ".";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.Tecla);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(399, 179);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(57, 30);
            this.button29.TabIndex = 1;
            this.button29.Text = "CE";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(30, 178);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(30, 29);
            this.button30.TabIndex = 1;
            this.button30.Text = "Z";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.Tecla);
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(175, 179);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(30, 29);
            this.button31.TabIndex = 1;
            this.button31.Text = "B";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.Tecla);
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(102, 177);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(30, 29);
            this.button32.TabIndex = 1;
            this.button32.Text = "C";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.Tecla);
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(247, 178);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(30, 29);
            this.button33.TabIndex = 1;
            this.button33.Text = "M";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.Tecla);
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(363, 179);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(30, 29);
            this.button34.TabIndex = 1;
            this.button34.Text = "-";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.Tecla);
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(66, 214);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(31, 30);
            this.button35.TabIndex = 1;
            this.button35.Text = "2";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.Tecla);
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(138, 213);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(31, 30);
            this.button36.TabIndex = 1;
            this.button36.Text = "4";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.Tecla);
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(211, 215);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(31, 30);
            this.button37.TabIndex = 1;
            this.button37.Text = "6";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.Tecla);
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(283, 214);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(31, 30);
            this.button38.TabIndex = 1;
            this.button38.Text = "8";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.Tecla);
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(327, 216);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(31, 30);
            this.button39.TabIndex = 1;
            this.button39.Text = "9";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.Tecla);
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(399, 215);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(57, 30);
            this.button40.TabIndex = 1;
            this.button40.Text = "\'";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.Tecla);
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(30, 214);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(30, 29);
            this.button41.TabIndex = 1;
            this.button41.Text = "1";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.Tecla);
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(175, 215);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(30, 29);
            this.button42.TabIndex = 1;
            this.button42.Text = "5";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.Tecla);
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(102, 213);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(30, 29);
            this.button43.TabIndex = 1;
            this.button43.Text = "3";
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.Tecla);
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(247, 214);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(30, 29);
            this.button44.TabIndex = 1;
            this.button44.Text = "7";
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.Tecla);
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(363, 215);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(30, 29);
            this.button45.TabIndex = 1;
            this.button45.Text = "0";
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.Tecla);
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(30, 249);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(30, 29);
            this.button46.TabIndex = 1;
            this.button46.Text = "\"";
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.Tecla);
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(400, 249);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(56, 29);
            this.button47.TabIndex = 1;
            this.button47.Text = "*";
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.Tecla);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(462, 110);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(76, 168);
            this.button11.TabIndex = 5;
            this.button11.Text = "Bloq Mayus";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(66, 248);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(327, 30);
            this.button48.TabIndex = 1;
            this.button48.Text = "_";
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.Tecla);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 325);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button48;
    }
}

